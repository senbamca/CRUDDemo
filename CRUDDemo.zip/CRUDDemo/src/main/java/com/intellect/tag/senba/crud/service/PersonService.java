package com.intellect.tag.senba.crud.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.intellect.tag.senba.crud.model.Person;
import com.intellect.tag.senba.crud.model.Response;
import com.intellect.tag.senba.crud.repository.PersonRepository;

@Service
public class PersonService {

	@Autowired
	private PersonRepository personRepository;
	
	public Response savePerson(Person person) {
		return personRepository.savePerson(person);
	}
	
	public List<Person> getPersons(){
		return personRepository.getPersons();
	}
	
	public Response updatePerson(Person person) {
		return personRepository.updatePerson(person);
	}
	
	public Response deletePerson(Person person) {
		return personRepository.deletePerson(person);
	}
	
}
