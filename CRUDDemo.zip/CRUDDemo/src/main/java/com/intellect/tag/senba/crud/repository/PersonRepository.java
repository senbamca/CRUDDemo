package com.intellect.tag.senba.crud.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.intellect.tag.senba.crud.model.Person;
import com.intellect.tag.senba.crud.model.Response;
import com.intellect.tag.senba.crud.model.ValError;

@Repository
public class PersonRepository {

	private static List<Person> persons;
	
	public Response savePerson(Person person) {
		Response response = new Response();
		if(persons == null) {
			persons = new ArrayList<Person>();
		}
		if(isValidRequest(person)) {
			persons.add(person);
			response.setResMsg("Saved Successfully");
			response.setUserId(person.getId());
		}else {
			response.setResMsg("Save Failed");
			ValError e = new ValError();
			e.setMessage("Validations failed on Id OR Date fields...");
			List <ValError> valErrors = new ArrayList<ValError>(); 
			valErrors.add(e);
			response.setValErrors(valErrors);
		}
		return response;
	}
	
	public List<Person> getPersons(){
		return persons;
	}
	
	
	private boolean isValidRequest(Person person) {
		if(isValidId(person.getId()) && !isDuplicate(person) && isValidDate(person.getBirthDate())) {
			return true;
		}
		return false;
	}
	
	private boolean isValidId(String id) {
		if(Optional.ofNullable(id).isPresent()) {
			return true;
		}
		return false;
	}
	
	private boolean isValidDate(Date date) {
		if(Optional.ofNullable(date).isPresent()) {
			return (new Date().after(date));
		}
		return false;
	}
	
	private boolean isDuplicate(Person person) {
		if(!persons.isEmpty()) {
			List<Person> filtered = persons.stream().filter(p -> p.getId().equalsIgnoreCase(person.getId())).collect(Collectors.toList());
			if(!filtered.isEmpty()) {
				return true;
			}
		}else {
			return false;
		}
		return false;
	}
	
	private List<Person> getDuplidate(Person person){
		if(isDuplicate(person)) {
			return persons.stream().filter(p -> p.getId().equalsIgnoreCase(person.getId())).collect(Collectors.toList());
		}
		return null;
	}
	
	public Response updatePerson(Person person) {
		Response response = new Response();
		if(Optional.ofNullable(person.getId()).isPresent()) {
			List<Person> filtered = getDuplidate(person);
			if(filtered.size() == 1) {
				if(isValidDate(person.getBirthDate())) {
					Person oldPerson = (Person)filtered.get(0);
					oldPerson.setPinCode(person.getPinCode());
					oldPerson.setBirthDate(person.getBirthDate());
					response.setResMsg("Updated Successfully");
					response.setUserId(person.getId());
				}else {
					response.setResMsg("Updated Failed");
					response.setUserId(person.getId());
					ValError e = new ValError();
					e.setMessage("Invalid Date...");
					List <ValError> valErrors = new ArrayList<ValError>(); 
					valErrors.add(e);
					response.setValErrors(valErrors);
				}
			}			
		}
		if(response.getUserId().isEmpty()) {
			response.setResMsg("Updated Failed");
			response.setUserId(person.getId());
			ValError e = new ValError();
			e.setMessage("Unable to Update Data...");
			List <ValError> valErrors = new ArrayList<ValError>(); 
			valErrors.add(e);
			response.setValErrors(valErrors);

		}
		return response;
	}
	
	public Response deletePerson(Person person) {
		Response response = new Response();
		if(Optional.ofNullable(person.getId()).isPresent()) {
			List<Person> filtered = getDuplidate(person);
			if(filtered.size() == 1) {
					Person oldPerson = (Person)filtered.get(0);
					oldPerson.setActive(false);
					response.setResMsg("Deactivated Successfully");
					response.setUserId(person.getId());
			}			
		}
		if(response.getUserId().isEmpty()) {
			response.setResMsg("Updated Failed");
			response.setUserId(person.getId());
			ValError e = new ValError();
			e.setMessage("Unable to Update Data...");
			List <ValError> valErrors = new ArrayList<ValError>(); 
			valErrors.add(e);
			response.setValErrors(valErrors);

		}
		return response;

	}
	
	
	
}
