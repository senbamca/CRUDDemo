package com.intellect.tag.senba.crud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.intellect.tag.senba.crud.model.Person;
import com.intellect.tag.senba.crud.model.Response;
import com.intellect.tag.senba.crud.service.PersonService;

@RestController
@RequestMapping("/persons")
public class PersonController {

	@Autowired
	private PersonService personService;
	
	
	@PostMapping
	public ResponseEntity<Response> savePerson(@RequestBody Person person){
		Response response = personService.savePerson(person);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
		
	}
	
	@GetMapping
	public List<Person> getPersons(){
		return personService.getPersons();
	}
	
	@PutMapping
	public ResponseEntity<Response> updatePerson(@RequestBody Person person){
		Response response = personService.updatePerson(person);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
		
	}
	
	@PatchMapping
	public ResponseEntity<Response> deletePerson(@RequestBody Person person){
		Response response = personService.deletePerson(person);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
		
	}
}
